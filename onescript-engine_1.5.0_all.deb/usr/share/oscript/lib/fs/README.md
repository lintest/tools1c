# Часто применяемые операции для работы с файловой системой

[![GitHub release](https://img.shields.io/github/release/oscript-library/files-common.svg)](https://github.com/oscript-library/files-common/releases)

Данная библиотека содержит методы работы с файловой системой, наиболее часто применяемые при написании скриптов.
